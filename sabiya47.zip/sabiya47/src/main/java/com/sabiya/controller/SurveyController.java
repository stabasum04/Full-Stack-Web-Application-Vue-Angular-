package com.sabiya.controller;

import com.sabiya.model.Survey;
import com.sabiya.repository.SurveyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("/api/surveys")
public class SurveyController {
    @Autowired
    private SurveyRepository repository;

    @PostMapping
    public Survey createSurvey(@RequestBody Survey survey) {
        return repository.save(survey);
    }

    @GetMapping
    public List<Survey> getAllSurveys() {
        return repository.findAll();
    }
    
 
}
 