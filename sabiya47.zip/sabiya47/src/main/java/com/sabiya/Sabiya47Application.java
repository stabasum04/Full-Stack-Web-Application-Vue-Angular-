package com.sabiya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sabiya47Application {

	public static void main(String[] args) {
		SpringApplication.run(Sabiya47Application.class, args);
	}

}
